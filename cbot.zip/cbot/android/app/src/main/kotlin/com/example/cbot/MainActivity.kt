package com.example.cbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
